import { useEffect, useState } from "react";
import { XMLParser } from "fast-xml-parser";
// import validateXML from "./validateQueXML.js";

function UrediProfil() {

  return (
   <h1>moj profil</h1> 
  );
}

export default UrediProfil;
