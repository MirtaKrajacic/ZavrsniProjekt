import { Link, useNavigate } from "react-router-dom";

function Footer() {
  return (
    <footer
      className="text-dark text-center bg-light py-3 mt-4 w-100"
      style={{ left: 0 }}
    >
      <Link className="nav-link" to="/">
        <p className="mb-0">O nama</p>
      </Link>
    </footer>
  );
}

export default Footer;
